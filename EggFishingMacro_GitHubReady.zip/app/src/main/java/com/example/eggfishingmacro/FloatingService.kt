package com.example.eggfishingmacro

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(0xEE202A35.toInt())
        }
        root.addView(TextView(this).apply {
            text = "🥚 EGG MACRO"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
        })
        root.addView(Button(this).apply {
            text = "▶ START"
            setOnClickListener {
                TapAccessibilityService.instance?.startMacro()
            }
        })
        root.addView(Button(this).apply {
            text = "■ STOP"
            setOnClickListener {
                TapAccessibilityService.instance?.stopMacro()
            }
        })
        root.addView(Button(this).apply {
            text = "CLOSE"
            setOnClickListener { stopSelf() }
        })
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 20; y = 180 }
        panel = root
        params = p
        wm.addView(root, p)
    }
    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
