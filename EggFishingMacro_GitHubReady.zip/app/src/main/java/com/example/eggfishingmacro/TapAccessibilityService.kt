package com.example.eggfishingmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapAccessibilityService? = null
    }
    private val handler = Handler(Looper.getMainLooper())
    @Volatile var running = false
    private var tapX = 540f
    private var tapY = 960f
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            tap(tapX, tapY)
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopMacro() }
    override fun onDestroy() {
        stopMacro()
        if (instance === this) instance = null
        super.onDestroy()
    }
    fun startMacro() {
        if (running) return
        running = true
        handler.post(loop)
    }
    fun stopMacro() {
        running = false
        handler.removeCallbacks(loop)
    }
    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 70))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
